let currentPage = 1
let totalPages = 1
let bookId = null

function openBook(id) {
    bookId = id
    currentPage = 1

    fetch(`/buku/${id}/pages/`)
      .then(res => res.json())
      .then(data => {
        totalPages = data.total_pages
        document.getElementById('totalPages').innerText = totalPages
        loadPage()
    })
}

function loadPage() {
    const img = document.getElementById('bookImage')
    const mediaUrl = img.dataset.media

    img.src = mediaUrl + `buku/images/${bookId}/page_${currentPage}.png`

    document.getElementById('currentPage').innerText = currentPage
    document.getElementById('prevBtn').disabled = currentPage === 1
    document.getElementById('nextBtn').disabled = currentPage === totalPages
}

function nextPage() {
    if (currentPage < totalPages) {
      currentPage++
      loadPage()
    }
}

function prevPage() {
    if (currentPage > 1) {
      currentPage--
      loadPage()
    }
}