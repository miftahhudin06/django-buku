from django.contrib import admin
from .models import Buku, Pengguna

# Register your models here.
@admin.register(Buku)
class BukuAdmin(admin.ModelAdmin):
    list_display = ('judul', 'penulis', 'tahun_terbit', 'genre')
    search_fields = ('judul', 'penulis', 'genre')

@admin.register(Pengguna)
class BukuAdmin(admin.ModelAdmin):
    list_display = ('nama', 'email', 'password')
    search_fields = ('nama', 'email', 'password')