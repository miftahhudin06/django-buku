import os
import shutil
from django.conf import settings
from django.shortcuts import get_object_or_404, render, redirect
from .forms import BukuEditForm, BukuUploadForm, PenggunaForm, RegisterForm, LoginForm
from django.contrib import messages
from .models import Favorite, Pengguna, Buku
from django.core.paginator import Paginator
from django.db.models import Q

# Create your views here.

def login (request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email']
            password = form.cleaned_data['password']

            try:
                pengguna = Pengguna.objects.get(email=email)
                if pengguna.check_password(password):
                    request.session['pengguna_id'] = pengguna.id
                    return redirect('katalog')
                else:
                    form.add_error(None, 'Password salah')
            except Pengguna.DoesNotExist:
                form.add_error(None, 'Email tidak ditemukan')
    else:
        form = LoginForm()

    return render(request, 'login.html', {'form': form})

def register (request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Registrasi berhasil, silakan login')
            return redirect('login')
    else:
        form = RegisterForm()

    return render(request, 'register.html', {'form': form})

def logout (request):
    request.session.flush()   # hapus semua session
    return redirect('login')

def profil(request):
    if not request.session.get('pengguna_id'):
        return redirect('login')

    profil = Pengguna.objects.get(id=request.session['pengguna_id'])
    return render(request, 'profil.html', {'profil': profil})

def edit_profil(request, id):
    pengguna = get_object_or_404(Pengguna, id=id)

    if request.method == 'POST':
        form = PenggunaForm(request.POST, request.FILES, instance=pengguna)
        if form.is_valid():
            form.save()
            return redirect('edit_profil', id=pengguna.id)  # tetap di halaman yang sama
    else:
        form = PenggunaForm(instance=pengguna)

    return render(request, 'edit_profil.html', {'form': form,
        'pengguna': pengguna,})

def katalog (request):
    if not request.session.get('pengguna_id'):
        return redirect('login')

    pengguna = Pengguna.objects.get(
        id=request.session['pengguna_id']
    )

    buku = Buku.objects.all()

    q = request.GET.get('q')
    fav = request.GET.get('fav')

    if q:
        buku = Buku.filter(
            Q(judul__icontains=q) |
            Q(deskripsi__icontains=q) |
            Q(tahun_terbit__icontains=q)
        )

    if fav == '1':
        buku = Buku.filter(favorite__user=request.pengguna)

    paginator = Paginator(buku, 5)
    page = request.GET.get('page')
    buku = paginator.get_page(page)

    return render(request, "katalog.html", {'buku': buku, 'pengguna': pengguna})

def upload(request):
    if request.method == 'POST':
        form = BukuUploadForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('katalog')
    else:
        form = BukuUploadForm()

    return render(request, 'upload.html', {'form': form})

def edit_buku(request, id):
    buku = get_object_or_404(Buku, id=id)

    if request.method == 'POST':
        form = BukuEditForm(request.POST, request.FILES, instance=buku)
        if form.is_valid():
            form.save()
            return redirect('detail', id=buku.id)
    else:
        form = BukuEditForm(instance=buku)

    return render(request, 'edit_buku.html', {
        'form': form,
        'buku': buku
    })

def hapus_buku(request, id):
    buku = get_object_or_404(Buku, id=id)

    # hapus file PDF
    if buku.file_pdf and os.path.isfile(buku.file_pdf.path):
        os.remove(buku.file_pdf.path)

    # hapus folder image hasil konversi PDF
    image_folder = os.path.join(
        settings.MEDIA_ROOT,
        'buku/images',
        str(buku.id)
    )
    if os.path.exists(image_folder):
        shutil.rmtree(image_folder)

    buku.delete()
    return redirect('katalog')

def detail(request, id):
    buku = get_object_or_404(Buku, id=id)
    return render(request, 'detail.html', {'buku': buku})


def baca_buku(request, id):
    buku = get_object_or_404(Buku, id=id)

    # ambil halaman dari query (?page=1)
    page = int(request.GET.get('page', 1))

    image_dir = os.path.join(
        settings.MEDIA_ROOT,
        'buku/images',
        str(buku.id)
    )

    images = sorted([
        f for f in os.listdir(image_dir)
        if f.endswith('.png')
    ])

    total_pages = len(images)

    # validasi batas halaman
    if page < 1:
        page = 1
    if page > total_pages:
        page = total_pages

    current_image = images[page - 1]

    return render(request, 'preview.html', {
        'buku': buku,
        'page': page,
        'total_pages': total_pages,
        'image': current_image
    })