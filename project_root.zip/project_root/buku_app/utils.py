import fitz
import os

def pdf_to_images(pdf_path, out_dir):
    doc = fitz.open(pdf_path)
    os.makedirs(out_dir, exist_ok=True)

    for i, page in enumerate(doc):
        pix = page.get_pixmap()
        pix.save(f"{out_dir}/page_{i+1}.png")

    return len(doc)