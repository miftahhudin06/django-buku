from django.db import models
import os
from .utils import pdf_to_images
from django.contrib.auth.hashers import check_password

# Create your models here.
class Pengguna(models.Model):
    nama = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=255)
    avatar = models.ImageField(upload_to='avatars/', blank=True, null=True)

    @property
    def avatar_url(self):
        if self.avatar:
            return self.avatar.url
        return 'avatars/default.png'

    def check_password(self, raw_password):
        return check_password(raw_password, self.password)
    
    def __str__(self):
        return self.nama

class Buku(models.Model):
    GENRE = (
        ('Fiksi','Fiksi'),
        ('Komik','Komik'),
        ('Motivasi','Motivasi'),
    )
    judul = models.CharField(max_length=200)
    deskripsi = models.TextField()
    penulis = models.CharField(max_length=150)
    tahun_terbit = models.IntegerField()
    genre = models.CharField(max_length=100)
    halaman = models.IntegerField(default=0)
    keywords = models.TextField(blank=True)

    file_pdf = models.FileField(
        upload_to='buku/pdf/',
        blank=True,
        null=True
    )

    created_at = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)

        if self.file_pdf:
            pdf_path = self.file_pdf.path
            output_dir = os.path.join(
                os.path.dirname(pdf_path),
                '../images',
                str(self.id)
            )

            pdf_to_images(pdf_path, output_dir)

    def __str__(self):
        return self.judul

class Favorite(models.Model):
    pengguna = models.ForeignKey(Pengguna, on_delete=models.CASCADE)
    buku = models.ForeignKey(Buku, on_delete=models.CASCADE)