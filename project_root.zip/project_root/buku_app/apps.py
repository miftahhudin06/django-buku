from django.apps import AppConfig


class BukuAppConfig(AppConfig):
    name = 'buku_app'
