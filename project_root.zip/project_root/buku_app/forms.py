from django import forms
from django.contrib.auth.hashers import make_password
from .models import Pengguna, Buku
import re

class LoginForm(forms.Form):
    email = forms.EmailField(
    widget=forms.EmailInput(attrs={
        'type':'email',
        'name':'email',
        'class': 'form-control',
        'placeholder': 'Masukan Email'
    })
)

    password = forms.CharField(
    widget=forms.PasswordInput(attrs={
        'class': 'form-control',
        'type':'password',
        'name':'password',
        'placeholder': 'Masukkan password'
    })
)

class RegisterForm(forms.ModelForm):
    email = forms.EmailField(
        label="Email",
        widget=forms.EmailInput(attrs={
            'class': 'form-control',
            'type': 'email',
            'placeholder': 'Masukkan email',
        })
    )
    password1 = forms.CharField(
        label='Password',
        widget=forms.PasswordInput(attrs={
            'class': 'form-control pe-5',
            'type': 'password',
            'id': "Password",
            'placeholder': 'Masukkan password' })
    )
    password2 = forms.CharField(
        label='Konfirmasi Password',
        widget=forms.PasswordInput(attrs={
            'class': 'form-control pe-5',
            'type': 'password',
            'id': "confirmPassword",
            'placeholder': 'Masukkan konfirmasi password' })
    )

    class Meta:
        model = Pengguna
        fields = ['email']

    def clean_password1(self):
        password = self.cleaned_data.get("password1")

        if len(password) < 8:
            raise forms.ValidationError(
                "Password minimal 8 karakter."
            )

        if not re.search(r'[A-Z]', password):
            raise forms.ValidationError(
                "Password harus mengandung huruf besar."
            )

        if not re.search(r'[a-z]', password):
            raise forms.ValidationError(
                "Password harus mengandung huruf kecil."
            )

        if not re.search(r'[0-9]', password):
            raise forms.ValidationError(
                "Password harus mengandung angka."
            )

        return password

    def clean(self):
        cleaned_data = super().clean()
        p1 = cleaned_data.get("password1")
        p2 = cleaned_data.get("password2")

        if p1 and p2 and p1 != p2:
            raise forms.ValidationError("Password tidak sama")

        return cleaned_data
    
    def generate_nama(self, email):
        base = email.split('@')[0]
        nama = base.replace('.', ' ').replace('_', ' ').title()

        counter = 1
        original = nama
        while Pengguna.objects.filter(nama=nama).exists():
            nama = f"{original} {counter}"
            counter += 1

        return nama
    
    def save(self, commit=True):
        pengguna = super().save(commit=False)
        pengguna.nama = self.generate_nama(
            self.cleaned_data['email']
        )
        pengguna.password = make_password(
            self.cleaned_data['password1']
        )

        if commit:
            pengguna.save()

        return pengguna


class BukuUploadForm(forms.ModelForm):
    class Meta:
        model = Buku
        fields = ['file_pdf', 'judul', 'deskripsi', 'penulis', 'tahun_terbit', 'genre']

    def clean_file(self):
        file = self.cleaned_data.get('file')
        if not file.name.endswith('.pdf'):
            raise forms.ValidationError("File harus berupa PDF")
        return file

class BukuEditForm(forms.ModelForm):
    class Meta:
        model = Buku
        fields = ['file_pdf', 'judul', 'deskripsi', 'penulis', 'tahun_terbit']

    def clean_file(self):
        file = self.cleaned_data.get('file')
        if file and not file.name.endswith('.pdf'):
            raise forms.ValidationError("File harus berupa PDF")
        return file

class PenggunaForm(forms.ModelForm):
    class Meta:
        model = Pengguna
        fields = ['nama', 'email', 'avatar']